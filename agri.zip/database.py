from sqlalchemy import Column, Integer, String, create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# 1. Define the Database URL
# This will create a file named 'attendance.db' in the same folder.
SQLALCHEMY_DATABASE_URL = "sqlite:///./attendance.db"

# 2. Create the Database Engine
# 'check_same_thread=False' is needed only for SQLite.
engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)

# 3. Create a SessionLocal class
# Each instance of SessionLocal will be a database session.
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# 4. Create a Base class
# We will inherit from this class to create our database models.
Base = declarative_base()

# 5. Define the Attendance Model (Table)
class StudentAttendance(Base):
    __tablename__ = "attendance"

    # Primary Key (Auto Incrementing ID)
    id = Column(Integer, primary_key=True, index=True)
    
    # Student details
    student_name = Column(String)
    usn = Column(String)
    date = Column(String)
    status = Column(String)

# 6. Create the Database and Tables
# This line automatically creates the .db file and the tables if they don't exist.
Base.metadata.create_all(bind=engine)

print("Database and tables created successfully!")
