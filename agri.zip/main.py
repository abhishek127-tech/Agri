from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from pydantic import BaseModel
import database  # Importing our database.py file

# 1. Initialize FastAPI App
app = FastAPI()

# 2. Enable CORS (Cross-Origin Resource Sharing)
# This allows the frontend to talk to the backend.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 3. Pydantic Models for Data Validation
# This defines what data the API expects to receive.
class AttendanceCreate(BaseModel):
    student_name: str
    usn: str
    date: str
    status: str

class AttendanceResponse(AttendanceCreate):
    id: int
    class Config:
        from_attributes = True

# 4. Database Dependency
# This ensures we have a database session for each request and closes it after.
def get_db():
    db = database.SessionLocal()
    try:
        yield db
    finally:
        db.close()

# --- API ROUTES ---

# Route to serve the frontend (index.html)
@app.get("/")
def read_root():
    return FileResponse("index.html")

# Route to Add Attendance
@app.post("/add-attendance")
def add_attendance(attendance: AttendanceCreate, db: Session = Depends(get_db)):
    new_record = database.StudentAttendance(
        student_name=attendance.student_name,
        usn=attendance.usn,
        date=attendance.date,
        status=attendance.status
    )
    db.add(new_record)
    db.commit()
    db.refresh(new_record)
    return {"message": "Attendance added successfully!", "data": new_record}

# Route to Get All Attendance Records
@app.get("/attendance")
def get_all_attendance(db: Session = Depends(get_db)):
    records = db.query(database.StudentAttendance).all()
    return records

# Route to Delete Attendance Record by ID
@app.delete("/attendance/{id}")
def delete_attendance(id: int, db: Session = Depends(get_db)):
    record = db.query(database.StudentAttendance).filter(database.StudentAttendance.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail="Record not found")
    
    db.delete(record)
    db.commit()
    return {"message": f"Record with ID {id} deleted successfully"}

# To run the app, use: uvicorn main:app --reload
